<?php
/**************************************************************************
 *
 * Copyright (c) 2011 Baidu.com, Inc. All Rights Reserved
 *
 *************************************************************************/

/**
 * Exception class for the Bae Open API.
 * 
 * @package   BaeOpenAPI
 * @author	  yexw(yexinwei@baidu.com)
 * @version   $Revision: 1.10 $
 **/
class BaeException extends Exception
{

}

/* vim: set ts=4 sw=4 sts=4 tw=100 noet: */
?>